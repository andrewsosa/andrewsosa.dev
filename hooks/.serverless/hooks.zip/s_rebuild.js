var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'andrewsosa',
applicationName: 'andrewsosa-dev',
appUid: 'mgzJ3bDCSS7KQ333NW',
tenantUid: 'P5mzcM9tPfYNXmCNg9',
deploymentUid: '73da61fe-0103-4355-bb34-125be48d9117',
serviceName: 'hooks',
stageName: 'prod',
pluginVersion: '1.3.11'})
const handlerWrapperArgs = { functionName: 'hooks-prod-rebuild', timeout: 6}
try {
  const userHandler = require('./cronjob.js')
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
